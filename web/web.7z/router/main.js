module.exports = function(app, fs, rand){
	app.get('/', function(req, res){
		res.end("Under Construction.");
	});

	app.get('/tunnel', function(req, res){
		var session = req.session;

		if(typeof session.isAdmin == "boolean" && session.isAdmin){
			var param = req.query;
			if(typeof param.dir == 'undefined') param.dir = '';
			request = require('request');
			request.get('http://localhost/?dir='+param.dir, function callback(err, resp, body){
				var result = body;
				res.end(result);
			});
		}else{
			res.end("Permission Error");
		}
	});

	app.get('/auth', function(req, res){
		var session = req.session;

		var passcode = req.query.passcode;
		var secret = fs.readFileSync('passcode.txt','utf8').trim();
		if (typeof passcode  == "string" && !secret.search(passcode) && secret === passcode){
			var session = req.session;
			session.isAdmin = true;
				
			res.statusCode = 302;
			res.setHeader('Location', './tunnel');
			res.end();
		} else {
			res.end("Plz Enter Correct Passcode");
		}
	});

	app.put('/put', function(req, res){
		var session = req.session;
		if(typeof session.isAdmin == "boolean" && session.isAdmin){
			var filename = Buffer.from(rand.random(16)).toString('hex');
			var contents = req.query.contents;
			if(typeof contents == "undefined"){
				res.end('Param Error');
			}else if(contents.match(/ELF/gi)){
				res.end('Forbidden String');
			}else{
				var dir = './uploads/'+session.id;

				!fs.existsSync(dir) && fs.mkdirSync(dir);
				fs.writeFileSync(dir+'/'+filename+'.txt', contents);
				res.end('Okay');
			}
		}else{
			res.end('Permission Error');
		}
	});
}

